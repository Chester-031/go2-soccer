window.GO2_DATA = {
  "snapshotDate": "2026-11-26",
  "trainingStages": [
    {
      "label": "Initial goal-directed learning",
      "iteration": 2500,
      "seconds": 8388.6739079291,
      "cumulativeHours": 2.330187196646972,
      "envs": 4096
    },
    {
      "label": "Retention and harder starts",
      "iteration": 4000,
      "seconds": 4919.8911502007395,
      "cumulativeHours": 3.6968236272582886,
      "envs": 4096
    },
    {
      "label": "Expanded parallel training",
      "iteration": 6000,
      "seconds": 6671.858932035975,
      "cumulativeHours": 5.5501177750460595,
      "envs": 8192
    },
    {
      "label": "Recovery-aware feedback",
      "iteration": 8000,
      "seconds": 6786.559243738186,
      "cumulativeHours": 7.435273120528889,
      "envs": 8192
    },
    {
      "label": "Miss-origin practice",
      "iteration": 9000,
      "seconds": 3239.654329021927,
      "cumulativeHours": 8.335177100812757,
      "envs": 8192
    }
  ],
  "trainingSummary": {
    "iterations": 9000,
    "inheritedTransitions": 1376256000,
    "loggedTrainingSeconds": 30006.637562925927,
    "loggedTrainingHours": 8.335177100812757,
    "scope": "Selected checkpoint lineage only; excludes discarded canaries, evaluation, queue time, and non-inherited updates."
  },
  "benchmark": {
    "n": 1472,
    "earlyCount": 107,
    "finalCount": 962,
    "earlyPercent": 7.2690217391304355,
    "finalPercent": 65.35326086956522,
    "metric": "Joint task-and-stability pass rate",
    "scope": "Fixed development benchmark; cumulative improvements across policy versions, not an isolated reward ablation or held-out generalization result."
  },
  "distanceBreakdown": {
    "metric": "Stable scoring success",
    "predicate": "stable_goal AND task_goal",
    "distanceDefinition": "Initial ball-to-goal distance, not distance at contact or release.",
    "group": "Common factorial scenarios within the same fixed development benchmark",
    "orientationDegrees": [
      0,
      45,
      90,
      180
    ],
    "robotBallDistancesMeters": [
      0.8,
      1.6,
      2.4
    ],
    "casesPerFactorialCell": 16,
    "sourceSha256": "417cb3a3a2e851be90f1899525a241842514b038ed2186582430d21ba91cddbb",
    "rows": [
      {
        "distanceMeters": 2,
        "n": 192,
        "count": 189,
        "percent": 98.4375
      },
      {
        "distanceMeters": 4,
        "n": 192,
        "count": 177,
        "percent": 92.1875
      },
      {
        "distanceMeters": 6,
        "n": 192,
        "count": 144,
        "percent": 75.0
      }
    ],
    "scope": "Each distance includes 192 existing evaluation cases. Same goal, active-strike/release and strict-stability intersection as the overall benchmark; not the separate stable_kick_goal field."
  },
  "benchmarkBreakdown": {
    "metric": "Stable scoring success",
    "predicate": "stable_goal AND task_goal",
    "sourceSha256": "417cb3a3a2e851be90f1899525a241842514b038ed2186582430d21ba91cddbb",
    "n": 1472,
    "count": 962,
    "percent": 65.35326086956522,
    "rows": [
      {
        "group": "native",
        "label": "Native randomized starts",
        "n": 640,
        "count": 397,
        "percent": 62.03125000000001
      },
      {
        "group": "common",
        "label": "Common distance and orientation grid",
        "n": 576,
        "count": 510,
        "percent": 88.54166666666666
      },
      {
        "group": "joint_extreme",
        "label": "Combined extreme configurations",
        "n": 64,
        "count": 54,
        "percent": 84.375
      },
      {
        "group": "wall",
        "label": "Near-wall starts",
        "n": 64,
        "count": 1,
        "percent": 1.5625
      },
      {
        "group": "ball_behind",
        "label": "Ball-behind starts",
        "n": 64,
        "count": 0,
        "percent": 0.0
      },
      {
        "group": "recovery",
        "label": "Lying-orientation recovery starts",
        "n": 64,
        "count": 0,
        "percent": 0.0
      }
    ],
    "scope": "Complete disjoint breakdown of the same fixed development benchmark and exact shooting checkpoint. This is not the later rear-ball retrieval policy or a full skill-composition evaluation."
  },
  "otherConfigurations": {
    "label": "Other configurations outside the common distance grid",
    "n": 896,
    "count": 452,
    "percent": 50.44642857142857,
    "groups": [
      "native",
      "joint_extreme",
      "wall",
      "ball_behind",
      "recovery"
    ],
    "scope": "Complement of the 576 common-grid cases: native randomized starts, combined extreme configurations, near-wall starts, ball-behind starts and lying-orientation recovery starts. All use the same stable_goal AND task_goal predicate."
  },
  "shootingProgress": {
    "metric": "Stable scoring success",
    "predicate": "stable_goal AND task_goal",
    "n": 1472,
    "rows": [
      {
        "iteration": 2500,
        "label": "Initial goal-directed learning",
        "count": 107,
        "n": 1472,
        "percent": 7.2690217391304355,
        "checkpointSha256": "15dde583b5284053e24e653b323a6782894507bbb08becfa6aa6d85362131e1c",
        "sourceSha256": "a9f3a474603dcd730a1dc012ad4f5a3fd35ae0f83a4792278c20850a1eff9a89"
      },
      {
        "iteration": 4000,
        "label": "Retention and harder starts",
        "count": 279,
        "n": 1472,
        "percent": 18.953804347826086,
        "checkpointSha256": "89268d6f8031c000cf154826ba5d3d25fbac1e51b1feff56a3454dff2660803a",
        "sourceSha256": "afaabca94cbec77b6a8435ecad64aff19333d62941ec29d076c8451ef98c533d"
      },
      {
        "iteration": 6000,
        "label": "Expanded parallel practice",
        "count": 716,
        "n": 1472,
        "percent": 48.641304347826086,
        "checkpointSha256": "b7e406c77de8bf37a25796e0a4a39e599fe22a60f0f2074ea2fff2a1d7490e4c",
        "sourceSha256": "0a83a52e893977fde99211071d8fde3c22ce8c451e9cc375bd512c138ce2e690"
      },
      {
        "iteration": 8000,
        "label": "Recovery-aware feedback",
        "count": 855,
        "n": 1472,
        "percent": 58.08423913043478,
        "checkpointSha256": "f31f1f8ba54473b46a776787846c30e03706d4483eae8cf0aa219c1684179714",
        "sourceSha256": "075536d174a95a060a243445a1f6bdc12daa3b82ec6c15d2c375d2294a38e8cf"
      },
      {
        "iteration": 9000,
        "label": "Targeted starting-state practice",
        "count": 962,
        "n": 1472,
        "percent": 65.35326086956522,
        "checkpointSha256": "cfee8b33787235d6964ba6b187f635982f63d852895af1b96152bec2179d8205",
        "sourceSha256": "417cb3a3a2e851be90f1899525a241842514b038ed2186582430d21ba91cddbb"
      }
    ],
    "scope": "Recorded fixed-development-benchmark evaluations of selected ancestral checkpoints. These are cumulative policy improvements, not single-factor effects. Repeated evaluations of the same checkpoint can differ slightly; the original selected-checkpoint evaluations are shown here."
  },
  "latestOptimization": {
    "n": 1472,
    "parentIteration": 8000,
    "endpointIteration": 9000,
    "parentCount": 853,
    "endpointCount": 962,
    "additionalPassing": 109,
    "parentPercent": 57.9483695652174,
    "endpointPercent": 65.35326086956522,
    "percentagePointGain": 7.404891304347825,
    "parentSourceSha256": "c78519605babfb9c312a1ad547c34a2b2d104392e09906dc98d15fea54e5806a",
    "endpointSourceSha256": "417cb3a3a2e851be90f1899525a241842514b038ed2186582430d21ba91cddbb",
    "scope": "Same-transaction parent and endpoint evaluation after 1,000 further training iterations with targeted starting-state sampling. Net gain of 109 passing cases (209 gained, 100 lost), not 109 new successes without regressions or an isolated sampler-only effect. The parent reevaluation count is 853, distinct from the original 8000-checkpoint evaluation of 855 shown in the progress chart."
  }
};
