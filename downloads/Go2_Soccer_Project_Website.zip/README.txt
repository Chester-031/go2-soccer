GO2 SOCCER — PROJECT WEBSITE
Snapshot: 2026-11-26

HOW TO OPEN
1. Extract this entire ZIP into one folder.
2. Open index.html in a current desktop browser (Chrome, Edge, Firefox, or Safari).
3. Keep the assets folder beside index.html. No installation or account is required.

The included data.js allows the charts to work when opened directly from disk.
Videos are included as local files; a browser may require a click to start playback.
Each demonstration includes WebM and MP4 versions. The page prefers WebM and
provides direct links to both formats if the embedded player does not display.
Online-only download and share controls are hidden in the offline copy.

CONTENT GUIDE
Progress: fixed-benchmark scoring improvement and checkpoint-specific training.
My research: task objectives, reward design, starting-state sampling and evaluation.
Capabilities: acquisition-to-shooting, off-centre approach and scoring, locomotion.
Method: control architecture and the training/evaluation pipeline.
Training: recorded stage durations and parallel environments.

HOSTING OR MIGRATING
Upload the extracted page files and assets to a static website host.
Links and media use relative paths; no platform hostname is hard-coded.
The page does not require a server application, account, or build command.
To keep the hosted Download complete website button working, also create a
downloads folder and upload this ZIP there as Go2_Soccer_Project_Website.zip.

WHAT IS INCLUDED
The public project page, styles, chart data, and media only. This package does not
include model checkpoints, private experiment logs, credentials, or training code.
Numerical claims and footage captions retain the scope stated on the page.
Parallel-policy demonstration footage, when included, is frozen-policy playback
in independent simulation environments, not a recording of PPO optimization.

This is a dated snapshot. The public website may be updated after this download.
